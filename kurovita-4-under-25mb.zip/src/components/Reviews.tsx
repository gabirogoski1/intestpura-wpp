import { REVIEWS } from "../data/intestpuraData";

export function Reviews() {
  return (
    <section className="sec-white" id="reviews">
      <div className="wrap">
        {/* GARANTIA DE 90 DIAS (DESIGN ELEGANTE E PREMIUM LOGO ACIMA DE AVALIAÇÕES DO PRODUTO) */}
        <div className="guarantee-premium-card anim in">
          <div className="gpc-icon-wrap">
            <div className="gpc-shield-badge">🛡️</div>
          </div>
          <div className="gpc-content">
            <span className="gpc-tag">RISCO ZERO PARA VOCÊ</span>
            <h3 className="gpc-title">GARANTIA DE 90 DIAS</h3>
            <p className="gpc-subtitle">100% de satisfação ou seu dinheiro de volta</p>
          </div>
        </div>

        <h2 className="center anim in" style={{ marginTop: 42 }}>Avaliações do produto</h2>
        <p className="subh anim in">Confira as opiniões de quem já comprou!</p>

        <div className="rev-head anim in">
          <div className="score">
            4,9<span className="stars">★★★★★</span>
            <small>18.492 avaliações</small>
          </div>
          <div className="bars">
            <div className="barrow">
              <span className="lab">5 ★</span>
              <span className="track">
                <i style={{ width: "90%" }}></i>
              </span>
              <span className="cnt">16.550</span>
            </div>
            <div className="barrow">
              <span className="lab">4 ★</span>
              <span className="track">
                <i style={{ width: "8%" }}></i>
              </span>
              <span className="cnt">1.480</span>
            </div>
            <div className="barrow">
              <span className="lab">3 ★</span>
              <span className="track">
                <i style={{ width: "2%" }}></i>
              </span>
              <span className="cnt">310</span>
            </div>
            <div className="barrow">
              <span className="lab">2 ★</span>
              <span className="track">
                <i style={{ width: "1%" }}></i>
              </span>
              <span className="cnt">90</span>
            </div>
            <div className="barrow">
              <span className="lab">1 ★</span>
              <span className="track">
                <i style={{ width: "1%" }}></i>
              </span>
              <span className="cnt">62</span>
            </div>
          </div>
        </div>

        <div className="revs anim in">
          {REVIEWS.map((rev, i) => (
            <div
              key={i}
              className="rev"
              id={rev.text.includes("Eu tinha exatamente essa barriga de grávida") ? "stickyTrigger" : undefined}
            >
              <div className="top">
                <div className="av">
                  <img
                    src={rev.avatar}
                    alt=""
                    loading="eager"
                    decoding="async"
                    onError={(e) => {
                      e.currentTarget.onerror = null;
                      e.currentTarget.src = "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/c8332e77-f32f-45ab-91a0-a1ce8df39c98.png?v=1789505217";
                    }}
                  />
                </div>
                <div>
                  <div className="name">{rev.name}</div>
                  <div className="verif">✓ Verificada</div>
                </div>
              </div>
              <div className="stars">{rev.stars}</div>
              <p>"{rev.text}"</p>
              <div className="date">{rev.date}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
