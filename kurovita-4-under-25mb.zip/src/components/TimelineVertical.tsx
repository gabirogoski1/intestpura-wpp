interface TimelineStep {
  period: string;
  title: string;
  desc: string;
}

const STEPS: TimelineStep[] = [
  {
    period: "Dias 1 a 3",
    title: "Rompimento do Biofilme",
    desc: "Dissolve a armadura viscosa dos parasitas e cessa a liberação de toxinas.",
  },
  {
    period: "Dias 4 a 7",
    title: "O Grande Expurgo",
    desc: "Expulsão no vaso dos gases e resíduos presos. A barriga estufada murcha visivelmente.",
  },
  {
    period: "Dias 8 a 15",
    title: "Regulação do Intestino",
    desc: "Evacuação regular pela manhã e fim da compulsão noturna por doces.",
  },
  {
    period: "Dias 16 a 30+",
    title: "Blindagem e Cintura Fina",
    desc: "Mucosa cicatrizada, metabolismo destravado e abdômen plano duradouro.",
  },
];

export function TimelineVertical() {
  return (
    <section className="timeline-compact-section anim in">
      <div className="wrap">
        <div className="timeline-compact-box">
          <div className="timeline-compact-header">
            <span className="timeline-sub-tag">Cronograma</span>
            <h2 className="timeline-compact-title">
              O que acontece no seu corpo <span className="green">dia a dia</span>
            </h2>
          </div>

          <div className="timeline-compact-grid">
            {STEPS.map((s, idx) => (
              <div key={idx} className="timeline-compact-card">
                <div className="tc-step-num">{s.period}</div>
                <h4 className="tc-step-title">{s.title}</h4>
                <p className="tc-step-desc">{s.desc}</p>
              </div>
            ))}
          </div>

          <div className="timeline-compact-notice">
            <span>✓ Mais de 94% das mulheres sentem a barriga esvaziar entre o 4º e o 7º dia.</span>
          </div>
        </div>
      </div>
    </section>
  );
}
