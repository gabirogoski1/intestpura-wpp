import { useState } from "react";
import { WHATSAPP_TESTIMONIALS, WhatsAppTestimonial } from "../data/intestpuraData";

export function WhatsAppReviews() {
  const [activePhoto, setActivePhoto] = useState<string | null>(null);

  return (
    <div className="wa-reviews-section">
      <div className="wa-header-intro anim in">
        <div className="wa-chip">
          <span className="wa-icon-pulse">💬</span>
          <span>Mensagens no WhatsApp</span>
        </div>
        <h3 className="wa-main-title">
          Clientes que <span className="green">Receberam e Já Desincharam</span>
        </h3>
      </div>

      <div className="wa-cards-grid">
        {WHATSAPP_TESTIMONIALS.map((item: WhatsAppTestimonial) => (
          <div key={item.id} className="wa-card anim in">
            {/* WHATSAPP TOP BAR */}
            <div className="wa-top-bar">
              <div className="wa-user-info">
                <span className="wa-back-arrow">‹</span>
                <div className="wa-avatar-wrap">
                  <img
                    src={item.avatar}
                    alt={item.name}
                    className="wa-avatar-img"
                    loading="eager"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      e.currentTarget.onerror = null;
                      e.currentTarget.src = "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/c8332e77-f32f-45ab-91a0-a1ce8df39c98.png?v=1789505217";
                    }}
                  />
                  <span className="wa-online-dot"></span>
                </div>
                <div className="wa-user-text">
                  <div className="wa-name-row">
                    <b>{item.name}</b>
                    <span className="wa-verif-icon" title="Cliente Verificada">✓</span>
                  </div>
                  <span className="wa-status-text">
                    {item.city} - {item.state} · online
                  </span>
                </div>
              </div>
              <div className="wa-call-icons">
                <span className="wa-header-icon" title="Vídeo">📹</span>
                <span className="wa-header-icon" title="Ligação">📞</span>
                <span className="wa-header-icon" title="Opções">⋮</span>
              </div>
            </div>

            {/* WHATSAPP CHAT AREA */}
            <div className="wa-chat-area">
              <div className="wa-date-pill">HOJE</div>

              {/* MEDIA BUBBLE */}
              <div className="wa-bubble wa-bubble-media">
                <div
                  className="wa-media-container"
                  onClick={() => setActivePhoto(item.mediaUrl)}
                  title="Clique para ampliar"
                >
                  <img
                    src={item.mediaUrl}
                    alt={item.mediaCaption}
                    className="wa-media-img"
                    loading="eager"
                    decoding="async"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      e.currentTarget.onerror = null;
                      e.currentTarget.src = "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/c8332e77-f32f-45ab-91a0-a1ce8df39c98.png?v=1789505217";
                    }}
                  />
                  <div className="wa-zoom-badge">
                    <span>🔍 Toque para ampliar</span>
                  </div>
                </div>
                <div className="wa-media-caption">
                  <p>{item.mediaCaption}</p>
                </div>
              </div>

              {/* TEXT MESSAGE BUBBLE */}
              <div className="wa-bubble wa-bubble-in">
                <p className="wa-msg-text">{item.message}</p>
                <div className="wa-msg-meta">
                  <span className="wa-time">{item.time}</span>
                  <span className="wa-double-check">✓✓</span>
                </div>
                {/* REACTIONS */}
                <div className="wa-reactions">
                  {item.reactions.map((emoji, rIdx) => (
                    <span key={rIdx} className="wa-reaction-chip">
                      {emoji}
                    </span>
                  ))}
                </div>
              </div>

              {/* SUPPORT REPLY BUBBLE */}
              {item.supportReply && (
                <div className="wa-bubble wa-bubble-out">
                  <span className="wa-reply-sender">Suporte Intestpura Oficial</span>
                  <p className="wa-msg-text">{item.supportReply}</p>
                  <div className="wa-msg-meta">
                    <span className="wa-time">{item.time}</span>
                    <span className="wa-double-check wa-check-blue">✓✓</span>
                  </div>
                </div>
              )}
            </div>

            {/* WHATSAPP CARD FOOTER */}
            <div className="wa-card-footer">
              <span className="wa-footer-badge">
                🛡️ Compra Verificada · Envio Rápido Sedex
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* FULLSCREEN PHOTO MODAL */}
      {activePhoto && (
        <div className="wa-lightbox" onClick={() => setActivePhoto(null)}>
          <div className="wa-lightbox-content" onClick={(e) => e.stopPropagation()}>
            <button
              className="wa-lightbox-close"
              onClick={() => setActivePhoto(null)}
              aria-label="Fechar"
            >
              ✕
            </button>
            <img
              src={activePhoto}
              alt="Foto do produto"
              className="wa-lightbox-img"
              referrerPolicy="no-referrer"
            />
            <div className="wa-lightbox-caption">
              <span>Foto registrada por cliente Intestpura</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
