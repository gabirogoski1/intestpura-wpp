import { useRef, useState } from "react";
import type { MouseEvent, TouchEvent } from "react";
import { KITS, KitOffer } from "../data/intestpuraData";
import { GeoLocation } from "../services/geoService";

interface PricingOffersProps {
  selectedKit: KitOffer | null;
  onSelectKit: (kit: KitOffer) => void;
  hasError: boolean;
  onBuyClick: (e: MouseEvent) => void;
  userGeo?: GeoLocation | null;
  discountApplied?: boolean;
  kits?: KitOffer[];
}

export function PricingOffers({
  selectedKit,
  onSelectKit,
  hasError,
  onBuyClick,
  userGeo,
  discountApplied = false,
  kits,
}: PricingOffersProps) {
  const [ctaHighlighted, setCtaHighlighted] = useState(false);
  const ctaBtnRef = useRef<HTMLAnchorElement | null>(null);

  const touchStartPos = useRef<{ x: number; y: number } | null>(null);
  const isDragging = useRef(false);

  const activeKits = kits || KITS;

  const handleTouchStart = (e: TouchEvent) => {
    const touch = e.touches[0];
    touchStartPos.current = { x: touch.clientX, y: touch.clientY };
    isDragging.current = false;
  };

  const handleTouchMove = (e: TouchEvent) => {
    if (!touchStartPos.current) return;
    const touch = e.touches[0];
    const diffX = Math.abs(touch.clientX - touchStartPos.current.x);
    const diffY = Math.abs(touch.clientY - touchStartPos.current.y);
    if (diffX > 8 || diffY > 8) {
      isDragging.current = true;
    }
  };

  const handleOfferInteraction = (kit: KitOffer) => {
    if (isDragging.current) {
      isDragging.current = false;
      return;
    }

    onSelectKit(kit);

    if (typeof navigator !== "undefined" && "vibrate" in navigator) {
      try {
        navigator.vibrate([40, 30, 40]);
      } catch {
        // Ignore
      }
    }

    setCtaHighlighted(true);
    setTimeout(() => {
      setCtaHighlighted(false);
    }, 900);

    setTimeout(() => {
      if (ctaBtnRef.current) {
        ctaBtnRef.current.scrollIntoView({
          behavior: "smooth",
          block: "center",
        });
      }
    }, 60);
  };

  return (
    <section className="sec-white pricing-offers-section" id="offers" style={{ paddingBottom: 16 }}>
      <div className="wrap">
        <div style={{ maxWidth: 640, margin: "0 auto" }}>
          <div className="hero-right" style={{ padding: 0 }}>
            <div id="escolha-protocolo" style={{ scrollMarginTop: "80px", textAlign: "center", marginBottom: 20 }}>
              <h2 style={{ margin: 0, lineHeight: 1.1, textTransform: "uppercase" }}>
                <span style={{ color: "var(--verde-esc)", fontWeight: 900, fontSize: "clamp(28px, 5.5vw, 38px)", letterSpacing: "1.5px" }}>INTEST</span>
                <span style={{ color: "var(--laranja)", fontWeight: 900, fontSize: "clamp(28px, 5.5vw, 38px)", letterSpacing: "1.5px" }}>PURA</span>
              </h2>
              <div style={{ fontSize: "clamp(13.5px, 3vw, 16px)", fontWeight: 800, color: "var(--verde-esc)", textTransform: "uppercase", letterSpacing: "2px", marginTop: 5 }}>
                Escolha o seu protocolo
              </div>
            </div>

            {discountApplied && (
              <div className="discount-applied-banner">
                <div className="dab-header">
                  <span className="dab-fire">💥</span>
                  <span className="dab-title">30% DE DESCONTO EXTRA ATIVADO!</span>
                </div>
                <p className="dab-sub">
                  Desconto de retenção aplicado com sucesso para{" "}
                  <b>{userGeo?.city || "sua região"}</b>. Todos os kits abaixo com Frete Grátis incluso:
                </p>
              </div>
            )}

            <div className={`offers ${discountApplied ? "offers-discount-applied" : ""}`}>
              {activeKits.map((kit) => {
                const isSelected = selectedKit?.id === kit.id;
                return (
                  <div
                    key={kit.id}
                    role="button"
                    tabIndex={0}
                    className={`offer ${isSelected ? "sel" : ""} ${
                      hasError ? "erro" : ""
                    } ${discountApplied ? "offer-discounted" : ""}`}
                    onTouchStart={handleTouchStart}
                    onTouchMove={handleTouchMove}
                    onClick={() => handleOfferInteraction(kit)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" || e.key === " ") {
                        handleOfferInteraction(kit);
                      }
                    }}
                  >
                    <span className={`offer-tag ${kit.tagClass}`}>
                      {kit.tag}
                    </span>
                    <span className="radio"></span>
                    <span className={`thumb ${kit.thumbClass}`}>
                      <img src={kit.image} alt={kit.title} loading="lazy" />
                      {!kit.hideQtyBadge && <i className="qty">{kit.qty}</i>}
                    </span>
                    <span className="offer-body">
                      <span className="offer-title">{kit.title}</span>
                      <br />
                      {kit.id === "kit-6" ? (
                        <>
                          <span className="offer-eco">
                            <span className="offer-eco-protocol">
                              Protocolo <strong>Completo</strong> 180 dias
                            </span>
                            <span className="offer-eco-dot"> · </span>
                            <strong className="offer-eco-save">
                              {kit.subtitle.includes("Desconto")
                                ? "Desconto de 30% aplicado"
                                : "Economize 67%"}
                            </strong>
                          </span>
                          {kit.bonusGift && (
                            <div className="offer-bonus-row">
                              <span className="offer-bonus-badge">
                                <span className="obb-icon">🎁</span>
                                <span className="obb-text">{kit.bonusGift}</span>
                              </span>
                            </div>
                          )}
                        </>
                      ) : (
                        <>
                          <span className="offer-eco">{kit.subtitle}</span>
                          {kit.bonusGift && (
                            <div className="offer-bonus-row">
                              <span className="offer-bonus-badge">
                                <span className="obb-icon">🎁</span>
                                <span className="obb-text">{kit.bonusGift}</span>
                              </span>
                            </div>
                          )}
                        </>
                      )}
                    </span>
                    <span className="offer-price">
                      <span className="offer-old">{kit.oldPrice}</span>
                      <span className="offer-new">{kit.newPrice}</span>
                    </span>
                  </div>
                );
              })}
            </div>

            <a
              ref={ctaBtnRef}
              href={selectedKit?.url || "#"}
              className={`cta js-buy ${ctaHighlighted ? "cta-selected-vibrate" : ""}`}
              data-buy-main=""
              onClick={onBuyClick}
            >
              <span className="cta-gift-tag">
                <span className="cgt-icon">🎁</span>
                <span className="cgt-text">+ Brinde</span>
              </span>
              <span className="cta-main">Comprar Agora →</span>
              {selectedKit && (
                <span className="buy-kit">
                  <span className="bk-pill-icon">✓</span>
                  {selectedKit.title.replace(/\s*·\s*/g, " - ")} - {selectedKit.newPrice}
                </span>
              )}
            </a>
            <div className={`offer-aviso ${hasError ? "visivel" : ""}`}>
              Selecione uma opção para comprar
            </div>

            {/* PAINEL CONSOLIDADO DE CONFIANÇA */}
            <div className="hero-trust-card" style={{ marginBottom: 0, paddingBottom: 14 }}>
              <div className="htc-pay-row" style={{ borderBottom: "none", paddingBottom: 0, marginBottom: 0 }}>
                <span className="htc-lock">🔒 Pagamento 100% seguro:</span>
                <div className="pays">
                  <svg className="pi"><use href="#pi-visa" /></svg>
                  <svg className="pi"><use href="#pi-mc" /></svg>
                  <svg className="pi"><use href="#pi-elo" /></svg>
                  <svg className="pi"><use href="#pi-amex" /></svg>
                  <svg className="pi"><use href="#pi-pix" /></svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
