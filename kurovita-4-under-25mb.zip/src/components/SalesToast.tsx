import { useEffect, useState, useRef, useCallback } from "react";
import {
  detectUserLocation,
  buildSalesQueue,
  BRAZIL_CUSTOMER_NAMES,
  CityItem,
} from "../services/geoService";
import { IMAGE_KIT_6_POTES } from "../data/intestpuraData";

interface SalesToastProps {
  currentStock?: number;
  onSaleNotice?: (bottles: number) => void;
}

const KITS_LIST = [
  {
    title: "Compre 1 · Leve 2",
    img: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/d2750d24-c18a-480e-ac4c-509cbeb2f4ad.png?v=1789349245",
    bottles: 2,
  },
  {
    title: "Compre 2 · Leve 3",
    img: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/8ce3ab86-6b88-4467-b21d-a41464b0d5ed.png?v=1789349359",
    bottles: 3,
  },
  {
    title: "Compre 3 · Leve 6",
    img: IMAGE_KIT_6_POTES,
    bottles: 6,
  },
];

// Intervalos de segundos alternados após a notificação desaparecer (9s, 4s, 12s, 6s, 10s, 5s, 11s, 7s...)
const ALTERNATING_DELAYS_MS = [
  9000,
  4000,
  12000,
  6000,
  10000,
  5000,
  11000,
  7000,
  9000,
  4000,
  12000,
  5000,
];

// Gerenciador de áudio robusto e imediato
let audioCtx: AudioContext | null = null;
let htmlAudioFallback: HTMLAudioElement | null = null;

// Inicializa ou retoma o AudioContext
function initAudio() {
  try {
    if (!audioCtx) {
      const AudioCtxClass =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtxClass) {
        audioCtx = new AudioCtxClass();
      }
    }
    if (audioCtx && audioCtx.state === "suspended") {
      audioCtx.resume().catch(() => {});
    }
  } catch {
    // Ignore
  }
}

// Escuta qualquer interação inicial para desbloquear o áudio
if (typeof window !== "undefined") {
  const tryUnlock = () => {
    initAudio();
    // Toca um buffer silencioso para registrar permissão no navegador
    if (audioCtx) {
      try {
        const silentBuf = audioCtx.createBuffer(1, 1, 22050);
        const src = audioCtx.createBufferSource();
        src.buffer = silentBuf;
        src.connect(audioCtx.destination);
        src.start(0);
      } catch {
        // Ignore
      }
    }
  };

  window.addEventListener("pointerdown", tryUnlock, { passive: true });
  window.addEventListener("touchstart", tryUnlock, { passive: true });
  window.addEventListener("click", tryUnlock, { passive: true });
  window.addEventListener("scroll", tryUnlock, { passive: true });
}

/**
 * Som de notificação agradável, nítido e encorpado:
 * Acorde suave em tom quente (Wood Marimba Pop) com presença clara para ser ouvido facilmente
 */
function playWarmWoodPop() {
  try {
    initAudio();

    if (audioCtx) {
      const now = audioCtx.currentTime;

      // 1. Tom principal quente e arredondado (frequência 520Hz descendo para 380Hz)
      const osc1 = audioCtx.createOscillator();
      const gain1 = audioCtx.createGain();

      osc1.type = "sine";
      osc1.frequency.setValueAtTime(520, now);
      osc1.frequency.exponentialRampToValueAtTime(380, now + 0.09);

      // Volume audível, limpo e sem distorcer (pico 0.22)
      gain1.gain.setValueAtTime(0, now);
      gain1.gain.linearRampToValueAtTime(0.22, now + 0.015);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.22);

      osc1.connect(gain1);
      gain1.connect(audioCtx.destination);

      osc1.start(now);
      osc1.stop(now + 0.24);

      // 2. Harmônico sutil e macio (tom de marimba/madeira para dar corpo)
      const osc2 = audioCtx.createOscillator();
      const gain2 = audioCtx.createGain();

      osc2.type = "triangle";
      osc2.frequency.setValueAtTime(780, now);
      osc2.frequency.exponentialRampToValueAtTime(560, now + 0.08);

      gain2.gain.setValueAtTime(0, now);
      gain2.gain.linearRampToValueAtTime(0.12, now + 0.012);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

      osc2.connect(gain2);
      gain2.connect(audioCtx.destination);

      osc2.start(now);
      osc2.stop(now + 0.20);
    }
  } catch {
    // Fallback silencioso se o sistema de áudio falhar
  }
}

export function SalesToast({ currentStock, onSaleNotice }: SalesToastProps) {
  const [visible, setVisible] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [queue, setQueue] = useState<CityItem[]>([]);

  // Timers & Cycle refs
  const hideTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const nextTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isDestroyedRef = useRef(false);
  const cycleCountRef = useRef(0);
  const queueRef = useRef<CityItem[]>([]);
  const currentIndexRef = useRef(0);
  const onSaleNoticeRef = useRef(onSaleNotice);
  const currentStockRef = useRef(currentStock);

  useEffect(() => {
    onSaleNoticeRef.current = onSaleNotice;
  }, [onSaleNotice]);

  useEffect(() => {
    currentStockRef.current = currentStock;
    // Se o estoque já atingiu 17 ou menos, cancela agendamentos futuros
    if (currentStock !== undefined && currentStock <= 17) {
      if (nextTimerRef.current) {
        clearTimeout(nextTimerRef.current);
        nextTimerRef.current = null;
      }
    }
  }, [currentStock]);

  // Initialize geo and city rotation queue (only cities from lead's state/region)
  useEffect(() => {
    isDestroyedRef.current = false;

    async function loadGeo() {
      const geo = await detectUserLocation();
      if (isDestroyedRef.current) return;
      const initialQueue = buildSalesQueue(geo.stateCode, geo.city);
      queueRef.current = initialQueue;
      setQueue(initialQueue);
    }

    loadGeo();

    return () => {
      isDestroyedRef.current = true;
    };
  }, []);

  const triggerCycle = useCallback(() => {
    if (isDestroyedRef.current) return;

    // Se o estoque já chegou em torno de 17 unidades ou menos, para de disparar notificações
    if (currentStockRef.current !== undefined && currentStockRef.current <= 17) {
      setVisible(false);
      return;
    }

    const currentQ = queueRef.current;
    if (currentQ.length === 0) return;

    // Advance to next city
    const nextIndex = (currentIndexRef.current + 1) % currentQ.length;
    currentIndexRef.current = nextIndex;
    setCurrentIndex(nextIndex);
    setVisible(true);

    // Toca som suave, aveludado e encorpado (em ~75% das notificações)
    playWarmWoodPop();

    // Cada notificação permanece visível por 5 segundos (1s a mais)
    const displayDuration = 5000;

    // Intervalo alternado após ela sumir
    const delayAfterHide =
      ALTERNATING_DELAYS_MS[cycleCountRef.current % ALTERNATING_DELAYS_MS.length];
    cycleCountRef.current += 1;

    // Notify parent for live stock counter
    if (onSaleNoticeRef.current) {
      const kitIndex = nextIndex % KITS_LIST.length;
      onSaleNoticeRef.current(KITS_LIST[kitIndex].bottles);
    }

    // 1. Permanece visível por exatamente 4 segundos
    if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    hideTimerRef.current = setTimeout(() => {
      if (isDestroyedRef.current) return;
      setVisible(false);

      // 2. Depois que desapareceu, aguarda o intervalo alternado para subir a próxima
      if (nextTimerRef.current) clearTimeout(nextTimerRef.current);
      nextTimerRef.current = setTimeout(() => {
        if (!isDestroyedRef.current) {
          triggerCycle();
        }
      }, delayAfterHide);
    }, displayDuration);
  }, []);

  useEffect(() => {
    if (queue.length === 0) return;

    // Primeira notificação sobe após 2 segundos de carregamento da página
    const initialStart = setTimeout(() => {
      triggerCycle();
    }, 2000);

    return () => {
      clearTimeout(initialStart);
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
      if (nextTimerRef.current) clearTimeout(nextTimerRef.current);
    };
  }, [queue.length, triggerCycle]);

  const handleClose = () => {
    if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    if (nextTimerRef.current) clearTimeout(nextTimerRef.current);

    setVisible(false);

    // Ao fechar manualmente, calcula o intervalo alternado para a próxima
    const delayAfterHide =
      ALTERNATING_DELAYS_MS[cycleCountRef.current % ALTERNATING_DELAYS_MS.length];
    cycleCountRef.current += 1;

    nextTimerRef.current = setTimeout(() => {
      if (!isDestroyedRef.current) {
        triggerCycle();
      }
    }, delayAfterHide);
  };

  if (queue.length === 0) return null;

  const currentCity = queue[currentIndex % queue.length];
  const customerName =
    BRAZIL_CUSTOMER_NAMES[currentIndex % BRAZIL_CUSTOMER_NAMES.length];
  const kit = KITS_LIST[currentIndex % KITS_LIST.length];
  const minutesAgo = 2 + ((currentIndex * 5) % 19);

  return (
    <div
      className={`salespop ${visible ? "show" : ""}`}
      role="status"
      aria-live="polite"
    >
      {/* Botão X para fechar a notificação caso a pessoa queira */}
      <button
        type="button"
        className="salespop-close"
        onClick={handleClose}
        aria-label="Fechar notificação"
        title="Fechar notificação"
      >
        ✕
      </button>

      <div className="av">
        <img src={kit.img} alt={kit.title} />
      </div>
      <div className="txt" style={{ paddingRight: 14 }}>
        {customerName} de{" "}
        <b className="city-highlight">
          {currentCity.city}-{currentCity.state}
        </b>{" "}
        acabou de garantir o{" "}
        <span style={{ color: "var(--verde-esc)", fontWeight: 700, whiteSpace: "nowrap" }}>
          {kit.title}
        </span>
        <small>
          há {minutesAgo} minutos · frete grátis via Sedex ✓
        </small>
      </div>
    </div>
  );
}
