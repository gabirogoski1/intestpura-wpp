import { useEffect, useRef } from "react";

const VIDEO_URL = "https://cdn.shopify.com/videos/c/o/v/f7b4dc2813c44e3b980e5d871a8bd199.mp4";

export function ShockVideo() {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    // 1. Configurações essenciais para conformidade de autoplay no iOS Safari e Android Chrome
    video.muted = true;
    video.defaultMuted = true;
    video.playsInline = true;
    video.loop = true;
    video.autoplay = true;

    // Atributos HTML explícitos no DOM (crucial para o parser WebKit)
    video.setAttribute("muted", "");
    video.setAttribute("autoplay", "");
    video.setAttribute("playsinline", "");
    video.setAttribute("webkit-playsinline", "true");
    video.setAttribute("x5-playsinline", "true");
    video.setAttribute("x5-video-player-type", "h5");
    video.setAttribute("preload", "auto");

    let isDestroyed = false;

    const playSafe = () => {
      if (isDestroyed || !video) return;
      video.muted = true;
      video.defaultMuted = true;
      const promise = video.play();
      if (promise !== undefined) {
        promise.catch(() => {
          // Autoplay silenciado sem erro no console
        });
      }
    };

    // 2. Loop sem travamento (fallback caso o navegador congele no frame final)
    const onEnded = () => {
      if (!video) return;
      video.currentTime = 0;
      playSafe();
    };

    const onPause = () => {
      playSafe();
    };

    const onCanPlay = () => {
      playSafe();
    };

    video.addEventListener("ended", onEnded);
    video.addEventListener("pause", onPause);
    video.addEventListener("canplay", onCanPlay);
    video.addEventListener("loadedmetadata", onCanPlay);
    video.addEventListener("loadeddata", onCanPlay);

    // 3. Tenta iniciar imediatamente
    playSafe();

    // 4. IntersectionObserver: força o play assim que se aproximar da tela no celular
    let observer: IntersectionObserver | null = null;
    if (typeof IntersectionObserver !== "undefined") {
      observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              playSafe();
            }
          });
        },
        {
          rootMargin: "250px 0px 250px 0px",
          threshold: [0, 0.25, 0.5, 1],
        }
      );
      observer.observe(video);
    }

    // 5. Fallback adicional de primeiro toque/rolagem (caso haja restrição extrema de economia de bateria)
    const onFirstUserTouch = () => {
      playSafe();
    };
    window.addEventListener("scroll", onFirstUserTouch, { passive: true, once: true });
    window.addEventListener("touchstart", onFirstUserTouch, { passive: true, once: true });
    window.addEventListener("touchend", onFirstUserTouch, { passive: true, once: true });
    window.addEventListener("click", onFirstUserTouch, { passive: true, once: true });

    return () => {
      isDestroyed = true;
      if (observer) {
        observer.disconnect();
      }
      video.removeEventListener("ended", onEnded);
      video.removeEventListener("pause", onPause);
      video.removeEventListener("canplay", onCanPlay);
      video.removeEventListener("loadedmetadata", onCanPlay);
      video.removeEventListener("loadeddata", onCanPlay);
      window.removeEventListener("scroll", onFirstUserTouch);
      window.removeEventListener("touchstart", onFirstUserTouch);
      window.removeEventListener("touchend", onFirstUserTouch);
      window.removeEventListener("click", onFirstUserTouch);
    };
  }, []);

  return (
    <div
      className="shock-vid"
      style={{ pointerEvents: "none", userSelect: "none" }}
    >
      <video
        ref={videoRef}
        src={VIDEO_URL}
        autoPlay
        muted
        loop
        playsInline
        preload="auto"
        controls={false}
        disablePictureInPicture
        disableRemotePlayback
        style={{
          pointerEvents: "none",
          userSelect: "none",
          width: "100%",
          height: "100%",
          objectFit: "cover",
          display: "block",
        }}
      >
        <source src={VIDEO_URL} type="video/mp4" />
      </video>
    </div>
  );
}
