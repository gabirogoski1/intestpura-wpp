import { useState, useEffect, useRef } from "react";
import { GeoLocation } from "../services/geoService";

interface ExitIntentModalProps {
  userGeo: GeoLocation | null;
  onApplyDiscount: () => void;
}

export function ExitIntentModal({ userGeo, onApplyDiscount }: ExitIntentModalProps) {
  const [isOpen, setIsOpen] = useState(false);

  const hasTriggeredRef = useRef(false);

  useEffect(() => {
    // Check session storage to avoid re-triggering repeatedly if already triggered in this session
    const alreadyShown = sessionStorage.getItem("exit_intent_shown");
    if (alreadyShown) {
      hasTriggeredRef.current = true;
      return;
    }

    // Se o usuário clicou em atualizar a página no navegador, dispara logo após recarregar
    const pendingRefresh = sessionStorage.getItem("pending_exit_discount");
    if (pendingRefresh) {
      sessionStorage.removeItem("pending_exit_discount");
      triggerModal();
      return;
    }

    // Marca no storage caso o usuário clique em atualizar a página
    const handleBeforeUnload = () => {
      if (!hasTriggeredRef.current) {
        sessionStorage.setItem("pending_exit_discount", "true");
      }
    };
    window.addEventListener("beforeunload", handleBeforeUnload);

    // 1. Desktop: mouse sai pelo topo (apenas dispositivos com cursor/mouse real, nunca touch mobile)
    const isDesktopPointer = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
    const handleMouseLeave = (e: MouseEvent) => {
      if (isDesktopPointer && e.clientY <= 10 && !hasTriggeredRef.current) {
        triggerModal();
      }
    };

    if (isDesktopPointer) {
      document.addEventListener("mouseleave", handleMouseLeave);
    }

    // 2. Mobile: interceptação do botão voltar via History API
    try {
      window.history.pushState({ page: "landing" }, "", window.location.href);
    } catch {
      // ignore
    }

    const handlePopState = () => {
      if (!hasTriggeredRef.current) {
        triggerModal();
        try {
          window.history.pushState({ page: "landing" }, "", window.location.href);
        } catch {
          // ignore
        }
      }
    };

    window.addEventListener("popstate", handlePopState);

    return () => {
      if (isDesktopPointer) {
        document.removeEventListener("mouseleave", handleMouseLeave);
      }
      window.removeEventListener("popstate", handlePopState);
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, []);

  const triggerModal = () => {
    if (hasTriggeredRef.current) return;
    hasTriggeredRef.current = true;
    sessionStorage.setItem("exit_intent_shown", "true");
    setIsOpen(true);
    // Aplica o desconto de 30% e muda os links de redirecionamento das ofertas imediatamente
    onApplyDiscount();
  };

  const handleClose = () => {
    setIsOpen(false);

    // Smooth scroll down to the offers section
    setTimeout(() => {
      const offersSection = document.getElementById("offers") || document.getElementById("offer2");
      if (offersSection) {
        offersSection.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }, 150);
  };

  const cityDisplay = userGeo?.city ? userGeo.city : "sua região";

  if (!isOpen) return null;

  return (
    <div className="exit-modal-overlay" onClick={handleClose}>
      <div
        className="exit-modal-compact"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
      >
        {/* CLOSE BUTTON */}
        <button
          className="exit-modal-close"
          onClick={handleClose}
          aria-label="Fechar"
        >
          ✕
        </button>

        {/* TOP ALERT BADGE - EXPLICIT & HIGH IMPACT */}
        <div className="exit-compact-tag">
          <div className="exit-tag-alert">⚠️ ESPERE! NÃO FECHE A PÁGINA</div>
          <div className="exit-tag-promo">
            VOCÊ GANHOU <span className="exit-tag-highlight">30% DE DESCONTO</span>
          </div>
        </div>

        {/* PRODUCT PHOTO + OFFER SUMMARY */}
        <div className="exit-compact-body">
          <div className="exit-compact-img">
            <img
              src="https://cdn.shopify.com/s/files/1/0619/5075/5023/files/8ce3ab86-6b88-4467-b21d-a41464b0d5ed.png?v=1789349359"
              alt="Kit IntestPura Compre 2 Leve 3"
              loading="eager"
            />
          </div>

          <div className="exit-compact-info">
            <span className="exit-compact-discount">-30% DE DESCONTO</span>
            <h3 className="exit-compact-title">COMPRE 2 · LEVE 3 (3 Potes)</h3>
            <div className="exit-compact-pricing">
              <span className="exit-compact-old">De R$ 199,90</span>
              <div className="exit-compact-new">
                Por <b>R$ 139,90</b>
              </div>
              <span className="exit-compact-installments">ou 12x de R$ 14,05</span>
            </div>
            <div className="exit-compact-frete">
              🚚 <b>Frete Grátis</b> para {cityDisplay}
            </div>
          </div>
        </div>

        {/* HIGHLIGHTED CTA BUTTON */}
        <a
          href="https://seguro.vitaissuplementos.com/api/public/shopify?product=52550924468514&store=34723"
          className="exit-compact-cta"
          id="btn-exit-intent-buy"
        >
          APROVEITAR 30% DE DESCONTO AGORA →
        </a>

        {/* SUBTLE CLOSE TEXT */}
        <button
          type="button"
          className="exit-compact-skip"
          onClick={handleClose}
        >
          Fechar e ver outros kits com desconto
        </button>
      </div>
    </div>
  );
}
