import type { MouseEvent } from "react";
import { KitOffer } from "../data/intestpuraData";

interface StickyBarProps {
  show: boolean;
  selectedKit: KitOffer | null;
  onSelectOfferClick: (e: MouseEvent) => void;
}

export function StickyBar({ show, selectedKit, onSelectOfferClick }: StickyBarProps) {
  return (
    <div className={`stickybar ${show ? "show" : ""}`}>
      <div className="info">
        Intestpura 60 Cápsulas &nbsp;
        <span className="oldp">{selectedKit?.oldPrice || "R$ 449,90"}</span>
        <span className="newp">{selectedKit?.newPrice || "R$ 199,90"}</span>
      </div>
      <a
        href="#offers"
        className="js-buy"
        onClick={onSelectOfferClick}
      >
        Escolher Oferta →
      </a>
    </div>
  );
}
