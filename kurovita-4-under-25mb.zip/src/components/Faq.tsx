import { FAQS } from "../data/intestpuraData";

export function Faq() {
  return (
    <section className="sec-white">
      <div className="wrap">
        <h2 className="center anim in">Perguntas frequentes</h2>
        <div className="faq anim in" style={{ marginTop: 34 }}>
          {FAQS.map((item, i) => (
            <div key={i} className="faqitem">
              <div className="q">{item.question}</div>
              <p className="a">{item.answer}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
