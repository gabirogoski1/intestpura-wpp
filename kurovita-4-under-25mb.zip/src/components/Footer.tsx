import { useState } from "react";

export function Footer() {
  const [activeModal, setActiveModal] = useState<string | null>(null);

  const policyContent: Record<string, { title: string; text: string }> = {
    termos: {
      title: "Termos e Condições de Uso",
      text: "Ao navegar e realizar compras neste site, você concorda com nossos termos e condições de uso. Garantimos a privacidade e segurança de suas informações pessoais. Todos os direitos reservados à Intestpura.",
    },
    privacidade: {
      title: "Política de Privacidade",
      text: "Seus dados estão 100% seguros e protegidos. Não compartilhamos informações com terceiros, exceto estritamente para o processamento de pagamentos e envio via Correios Sedex.",
    },
    cookies: {
      title: "Política de Cookies",
      text: "Utilizamos cookies funcionais e de análise para oferecer uma experiência otimizada e navegação personalizada em nossa plataforma.",
    },
    envio: {
      title: "Política de Envio e Entrega",
      text: "Pedidos aprovados são despachados no mesmo dia útil. O envio é realizado com frete grátis via Correios Sedex para todo o território nacional com código de rastreio oficial.",
    },
    garantia: {
      title: "Política de Garantia de 90 Dias",
      text: "Oferecemos garantia incondicional de 90 dias. Se dentro desse prazo você não constatar resultados positivos na sua digestão, leveza e regularidade intestinal, devolvemos 100% do valor pago.",
    },
    devolucao: {
      title: "Devolução e Arrependimento",
      text: "Em conformidade com o Código de Defesa do Consumidor, você tem o direito de arrependimento em até 7 dias após o recebimento, ou 90 dias sob a nossa garantia de satisfação.",
    },
    reembolso: {
      title: "Política de Reembolso",
      text: "Os reembolsos são processados na mesma modalidade de pagamento original (estorno no cartão de crédito em até 2 faturas ou Pix na conta do titular em até 2 dias úteis).",
    },
  };

  return (
    <>
      <footer>
        <div className="wrap">
          <div className="logo" style={{ fontWeight: 800 }}>
            Intest<span style={{ color: "#E87E38", fontWeight: 800 }}>Pura</span>
          </div>
          <p style={{ maxWidth: 460 }}>
            Suplemento natural de Extrato Botânico Concentrado Puro. Fórmula
            avançada com fibras inteligentes e fitonutrientes — para desinchar, regular
            e renovar o seu intestino com leveza e vitalidade.
            <br />
            <br />
            ✉️ contato@vitaissuplementos.com
            <br />
            Seg a Sex, 8h às 18h
          </p>
          <div className="footpays">
            <span className="lbl">Formas de pagamento aceitas</span>
            <svg className="pi">
              <use href="#pi-visa" />
            </svg>
            <svg className="pi">
              <use href="#pi-mc" />
            </svg>
            <svg className="pi">
              <use href="#pi-elo" />
            </svg>
            <svg className="pi">
              <use href="#pi-amex" />
            </svg>
            <svg className="pi">
              <use href="#pi-hiper" />
            </svg>
            <svg className="pi">
              <use href="#pi-pix" />
            </svg>
            <svg className="pi">
              <use href="#pi-boleto" />
            </svg>
          </div>

          <div
            className="footlinks"
            style={{
              display: "flex",
              flexWrap: "wrap",
              gap: "9px 18px",
              marginTop: 20,
              paddingTop: 16,
              borderTop: "1px solid #1c4d3c",
            }}
          >
            <button
              type="button"
              onClick={() => setActiveModal("termos")}
              style={{
                color: "#cfeadd",
                fontSize: 12,
                textDecoration: "none",
                background: "none",
                border: "none",
                cursor: "pointer",
                padding: 0,
              }}
            >
              Termos de Uso
            </button>
            <button
              type="button"
              onClick={() => setActiveModal("privacidade")}
              style={{
                color: "#cfeadd",
                fontSize: 12,
                textDecoration: "none",
                background: "none",
                border: "none",
                cursor: "pointer",
                padding: 0,
              }}
            >
              Política de Privacidade
            </button>
            <button
              type="button"
              onClick={() => setActiveModal("cookies")}
              style={{
                color: "#cfeadd",
                fontSize: 12,
                textDecoration: "none",
                background: "none",
                border: "none",
                cursor: "pointer",
                padding: 0,
              }}
            >
              Política de Cookies
            </button>
            <button
              type="button"
              onClick={() => setActiveModal("envio")}
              style={{
                color: "#cfeadd",
                fontSize: 12,
                textDecoration: "none",
                background: "none",
                border: "none",
                cursor: "pointer",
                padding: 0,
              }}
            >
              Envio e Entrega
            </button>
            <button
              type="button"
              onClick={() => setActiveModal("garantia")}
              style={{
                color: "#cfeadd",
                fontSize: 12,
                textDecoration: "none",
                background: "none",
                border: "none",
                cursor: "pointer",
                padding: 0,
              }}
            >
              Garantia
            </button>
            <button
              type="button"
              onClick={() => setActiveModal("devolucao")}
              style={{
                color: "#cfeadd",
                fontSize: 12,
                textDecoration: "none",
                background: "none",
                border: "none",
                cursor: "pointer",
                padding: 0,
              }}
            >
              Devolução e Arrependimento
            </button>
            <button
              type="button"
              onClick={() => setActiveModal("reembolso")}
              style={{
                color: "#cfeadd",
                fontSize: 12,
                textDecoration: "none",
                background: "none",
                border: "none",
                cursor: "pointer",
                padding: 0,
              }}
            >
              Reembolso
            </button>
          </div>

          <div className="disc">
            * Este produto é um suplemento alimentar em cápsulas e não substitui uma
            alimentação equilibrada e hábitos de vida saudáveis. As afirmações
            desta página não foram avaliadas por órgão regulador para
            diagnosticar, tratar, curar ou prevenir qualquer doença. Resultados
            podem variar de pessoa para pessoa. Consulte um profissional de
            saúde antes de iniciar qualquer suplementação.
            <br />
            <br />
            Intestpura · © 2026 Intestpura. Todos os direitos reservados.
          </div>
        </div>
      </footer>

      {/* MODAL INSTITUCIONAL */}
      {activeModal && policyContent[activeModal] && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            backgroundColor: "rgba(0,0,0,0.65)",
            zIndex: 9999,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: 20,
          }}
          onClick={() => setActiveModal(null)}
        >
          <div
            style={{
              background: "#fff",
              borderRadius: 16,
              maxWidth: 500,
              width: "100%",
              padding: "26px 28px",
              boxShadow: "0 20px 40px rgba(0,0,0,0.3)",
              color: "#374b43",
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <h3
              style={{
                fontSize: 20,
                color: "#0c3b2e",
                marginBottom: 14,
                fontWeight: 700,
              }}
            >
              {policyContent[activeModal].title}
            </h3>
            <p
              style={{
                fontSize: 15,
                lineHeight: 1.6,
                color: "#556b62",
                marginBottom: 20,
              }}
            >
              {policyContent[activeModal].text}
            </p>
            <button
              type="button"
              onClick={() => setActiveModal(null)}
              style={{
                background: "#0f9d63",
                color: "#fff",
                border: "none",
                padding: "10px 22px",
                borderRadius: 999,
                fontWeight: 600,
                cursor: "pointer",
                float: "right",
              }}
            >
              Fechar
            </button>
          </div>
        </div>
      )}
    </>
  );
}
